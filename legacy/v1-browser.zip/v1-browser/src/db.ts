import type { Note } from './types'

const DB_NAME = 'yasashii-voice-notes'
const DB_VERSION = 1
const NOTES = 'notes'
const AUDIO = 'audio'

let dbPromise: Promise<IDBDatabase> | null = null

export function isIndexedDBAvailable(): boolean {
  return typeof indexedDB !== 'undefined'
}

function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise
  dbPromise = new Promise((resolve, reject) => {
    if (!isIndexedDBAvailable()) {
      reject(new Error('このブラウザーでは保存機能（IndexedDB）が使えません。'))
      return
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION)
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains(NOTES)) {
        const store = db.createObjectStore(NOTES, { keyPath: 'id' })
        store.createIndex('createdAt', 'createdAt')
      }
      if (!db.objectStoreNames.contains(AUDIO)) {
        db.createObjectStore(AUDIO)
      }
    }
    req.onsuccess = () => {
      const db = req.result
      db.onversionchange = () => db.close()
      resolve(db)
    }
    req.onerror = () => reject(req.error ?? new Error('保存領域を開けませんでした。'))
    req.onblocked = () => reject(new Error('別のタブが保存領域を使用中です。他のタブを閉じてください。'))
  })
  dbPromise.catch(() => {
    dbPromise = null
  })
  return dbPromise
}

function reqToPromise<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve()
    tx.onerror = () => reject(tx.error)
    tx.onabort = () => reject(tx.error ?? new Error('保存が中断されました。'))
  })
}

/** 録音本体とメタ情報をまとめて保存する（同一トランザクション） */
export async function saveNote(note: Note, blob: Blob): Promise<void> {
  const db = await openDB()
  const tx = db.transaction([NOTES, AUDIO], 'readwrite')
  tx.objectStore(NOTES).put(note)
  tx.objectStore(AUDIO).put(blob, note.id)
  await txDone(tx)
}

/** メタ情報だけを更新する（タイトル・メモの編集用） */
export async function updateNote(note: Note): Promise<void> {
  const db = await openDB()
  const tx = db.transaction(NOTES, 'readwrite')
  tx.objectStore(NOTES).put(note)
  await txDone(tx)
}

export async function getAllNotes(): Promise<Note[]> {
  const db = await openDB()
  const tx = db.transaction(NOTES, 'readonly')
  const notes = await reqToPromise(tx.objectStore(NOTES).getAll())
  return (notes as Note[]).sort((a, b) => b.createdAt - a.createdAt)
}

export async function getAudio(id: string): Promise<Blob | undefined> {
  const db = await openDB()
  const tx = db.transaction(AUDIO, 'readonly')
  return reqToPromise(tx.objectStore(AUDIO).get(id)) as Promise<Blob | undefined>
}

export async function deleteNote(id: string): Promise<void> {
  const db = await openDB()
  const tx = db.transaction([NOTES, AUDIO], 'readwrite')
  tx.objectStore(NOTES).delete(id)
  tx.objectStore(AUDIO).delete(id)
  await txDone(tx)
}

/** 保存領域が勝手に消されにくいよう、永続化を依頼する */
export async function requestPersistentStorage(): Promise<boolean> {
  try {
    if (navigator.storage?.persist) {
      return await navigator.storage.persist()
    }
  } catch {
    /* 対応していないブラウザーでは無視 */
  }
  return false
}

export async function getStorageEstimate(): Promise<{ usage: number; quota: number } | null> {
  try {
    if (navigator.storage?.estimate) {
      const { usage = 0, quota = 0 } = await navigator.storage.estimate()
      return { usage, quota }
    }
  } catch {
    /* ignore */
  }
  return null
}

/** IndexedDB のエラーを、人が読める日本語にする */
export function describeStorageError(err: unknown): string {
  const e = err as { name?: string; message?: string } | null
  const name = e?.name ?? ''
  if (name === 'QuotaExceededError') {
    return '保存できる容量がいっぱいです。不要な録音を削除するか、バックアップを取ってから削除してください。'
  }
  if (name === 'InvalidStateError' || name === 'UnknownError') {
    return 'ブラウザーの保存領域にアクセスできませんでした。プライベートモードや保存領域の制限が原因の場合があります。'
  }
  if (name === 'AbortError') {
    return '保存が中断されました。もう一度お試しください。'
  }
  return e?.message ? `保存に失敗しました（${e.message}）` : '保存に失敗しました。'
}
