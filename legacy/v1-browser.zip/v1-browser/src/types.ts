/** 録音1件のメタ情報。音声本体は別ストアに保存する。 */
export interface Note {
  id: string
  title: string
  memo: string
  createdAt: number
  updatedAt: number
  durationMs: number
  mimeType: string
  size: number
}

/** バックアップファイル（JSON）の形式 */
export interface BackupFile {
  app: 'yasashii-voice-notes'
  version: 1
  exportedAt: string
  notes: Array<Note & { audio: string }> // audio は data URL
}
