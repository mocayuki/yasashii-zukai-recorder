import { getAllNotes, getAudio, saveNote } from './db'
import { downloadBlob } from './format'
import type { BackupFile, Note } from './types'

function blobToDataURL(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result as string)
    reader.onerror = () => reject(reader.error ?? new Error('音声の読み込みに失敗しました。'))
    reader.readAsDataURL(blob)
  })
}

async function dataURLToBlob(dataURL: string, fallbackType: string): Promise<Blob> {
  const res = await fetch(dataURL)
  const blob = await res.blob()
  if (blob.type) return blob
  return new Blob([blob], { type: fallbackType })
}

export interface ExportProgress {
  done: number
  total: number
}

/** すべての録音とノートを 1 つの JSON ファイルにまとめてダウンロードする */
export async function exportBackup(onProgress?: (p: ExportProgress) => void): Promise<number> {
  const notes = await getAllNotes()
  const items: BackupFile['notes'] = []
  let done = 0
  for (const note of notes) {
    const blob = await getAudio(note.id)
    if (blob) {
      items.push({ ...note, audio: await blobToDataURL(blob) })
    }
    done += 1
    onProgress?.({ done, total: notes.length })
  }
  const file: BackupFile = {
    app: 'yasashii-voice-notes',
    version: 1,
    exportedAt: new Date().toISOString(),
    notes: items,
  }
  const json = JSON.stringify(file)
  const d = new Date()
  const pad = (n: number) => String(n).padStart(2, '0')
  const stamp = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}`
  downloadBlob(new Blob([json], { type: 'application/json' }), `yasashii-voice-notes-backup-${stamp}.json`)
  return items.length
}

export interface ImportResult {
  added: number
  skipped: number
}

function isNoteLike(v: unknown): v is Note & { audio: string } {
  if (!v || typeof v !== 'object') return false
  const o = v as Record<string, unknown>
  return (
    typeof o.id === 'string' &&
    typeof o.title === 'string' &&
    typeof o.audio === 'string' &&
    typeof o.createdAt === 'number'
  )
}

/** バックアップファイルを読み込み、まだ無い録音だけを追加する */
export async function importBackup(file: File, onProgress?: (p: ExportProgress) => void): Promise<ImportResult> {
  let parsed: unknown
  try {
    parsed = JSON.parse(await file.text())
  } catch {
    throw new Error('バックアップファイルを読み取れませんでした。このアプリで書き出した JSON ファイルを選んでください。')
  }
  const data = parsed as Partial<BackupFile> | null
  if (!data || data.app !== 'yasashii-voice-notes' || !Array.isArray(data.notes)) {
    throw new Error('このファイルは「やさしい録音ノート」のバックアップではないようです。')
  }
  const existing = new Set((await getAllNotes()).map((n) => n.id))
  let added = 0
  let skipped = 0
  let done = 0
  for (const raw of data.notes) {
    done += 1
    if (!isNoteLike(raw)) {
      skipped += 1
      onProgress?.({ done, total: data.notes.length })
      continue
    }
    if (existing.has(raw.id)) {
      skipped += 1
      onProgress?.({ done, total: data.notes.length })
      continue
    }
    const { audio, ...meta } = raw
    const blob = await dataURLToBlob(audio, meta.mimeType || 'audio/webm')
    const note: Note = {
      id: meta.id,
      title: meta.title || '録音',
      memo: typeof meta.memo === 'string' ? meta.memo : '',
      createdAt: meta.createdAt,
      updatedAt: typeof meta.updatedAt === 'number' ? meta.updatedAt : meta.createdAt,
      durationMs: typeof meta.durationMs === 'number' ? meta.durationMs : 0,
      mimeType: blob.type || meta.mimeType || 'audio/webm',
      size: blob.size,
    }
    await saveNote(note, blob)
    added += 1
    onProgress?.({ done, total: data.notes.length })
  }
  return { added, skipped }
}
