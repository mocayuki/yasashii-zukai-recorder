export interface ToastMessage {
  id: number
  text: string
  kind: 'ok' | 'error'
}

interface Props {
  toast: ToastMessage | null
  onClose: () => void
}

export default function Toast({ toast, onClose }: Props) {
  if (!toast) return null
  return (
    <div className={`toast toast--${toast.kind}`} role={toast.kind === 'error' ? 'alert' : 'status'} aria-live="polite">
      <span className="toast__icon" aria-hidden="true">
        {toast.kind === 'ok' ? '✓' : '！'}
      </span>
      <span className="toast__text">{toast.text}</span>
      <button type="button" className="toast__close" onClick={onClose} aria-label="閉じる">
        ×
      </button>
    </div>
  )
}
