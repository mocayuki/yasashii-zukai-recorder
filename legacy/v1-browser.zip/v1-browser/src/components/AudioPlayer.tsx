import { useEffect, useRef, useState } from 'react'
import { getAudio } from '../db'

interface Props {
  noteId: string
  onBlob?: (blob: Blob) => void
}

/** IndexedDB から音声を読み出して再生する */
export default function AudioPlayer({ noteId, onBlob }: Props) {
  const [url, setUrl] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const onBlobRef = useRef(onBlob)
  useEffect(() => {
    onBlobRef.current = onBlob
  }, [onBlob])

  useEffect(() => {
    let objectUrl: string | null = null
    let cancelled = false
    getAudio(noteId)
      .then((blob) => {
        if (cancelled) return
        if (!blob) {
          setError('音声データが見つかりませんでした。')
          return
        }
        objectUrl = URL.createObjectURL(blob)
        setUrl(objectUrl)
        onBlobRef.current?.(blob)
      })
      .catch((err: unknown) => {
        if (!cancelled) setError(`音声を読み込めませんでした。${(err as Error)?.message ?? ''}`)
      })
    return () => {
      cancelled = true
      if (objectUrl) URL.revokeObjectURL(objectUrl)
    }
  }, [noteId])

  // Chrome の webm 録音は長さ情報を持たないため、一度末尾まで飛ばして長さを確定させる
  const fixDuration = () => {
    const a = audioRef.current
    if (!a || Number.isFinite(a.duration)) return
    const onTimeUpdate = () => {
      a.removeEventListener('timeupdate', onTimeUpdate)
      a.currentTime = 0
    }
    a.addEventListener('timeupdate', onTimeUpdate)
    a.currentTime = 1e101
  }

  if (error) {
    return (
      <p className="alert" role="alert">
        {error}
      </p>
    )
  }
  if (!url) {
    return <p className="muted">音声を読み込んでいます…</p>
  }
  return (
    <audio ref={audioRef} className="player" src={url} controls preload="metadata" onLoadedMetadata={fixDuration}>
      お使いのブラウザーはこの音声を再生できません。
    </audio>
  )
}
