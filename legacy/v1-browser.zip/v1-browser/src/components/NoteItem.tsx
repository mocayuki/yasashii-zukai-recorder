import { useEffect, useRef, useState } from 'react'
import type { Note } from '../types'
import { deleteNote, describeStorageError, getAudio, updateNote } from '../db'
import { downloadBlob, extensionFor, formatBytes, formatDateTime, formatDuration, safeFileName } from '../format'
import AudioPlayer from './AudioPlayer'

interface Props {
  note: Note
  expanded: boolean
  autoFocusTitle: boolean
  onToggle: () => void
  onUpdated: (note: Note) => void
  onDeleted: (id: string) => void
  notify: (text: string, kind?: 'ok' | 'error') => void
}

export default function NoteItem({ note, expanded, autoFocusTitle, onToggle, onUpdated, onDeleted, notify }: Props) {
  const [title, setTitle] = useState(note.title)
  const [memo, setMemo] = useState(note.memo)
  const [saving, setSaving] = useState(false)
  const [savedAt, setSavedAt] = useState<number | null>(null)
  const [saveError, setSaveError] = useState<string | null>(null)
  const titleRef = useRef<HTMLInputElement | null>(null)

  useEffect(() => {
    if (expanded && autoFocusTitle) {
      const id = window.setTimeout(() => {
        titleRef.current?.focus()
        titleRef.current?.select()
      }, 50)
      return () => window.clearTimeout(id)
    }
  }, [expanded, autoFocusTitle])

  const dirty = title !== note.title || memo !== note.memo

  const save = async () => {
    const trimmed = title.trim() || note.title
    setSaving(true)
    setSaveError(null)
    const next: Note = { ...note, title: trimmed, memo, updatedAt: Date.now() }
    try {
      await updateNote(next)
      setTitle(trimmed)
      setSavedAt(next.updatedAt)
      onUpdated(next)
      notify('ノートを保存しました')
    } catch (err) {
      const msg = describeStorageError(err)
      setSaveError(msg)
      notify(msg, 'error')
    } finally {
      setSaving(false)
    }
  }

  const download = async () => {
    try {
      const blob = await getAudio(note.id)
      if (!blob) {
        notify('音声データが見つかりませんでした。', 'error')
        return
      }
      const ext = extensionFor(blob.type || note.mimeType)
      downloadBlob(blob, `${safeFileName(note.title)}.${ext}`)
      notify('音声のダウンロードをはじめました')
    } catch (err) {
      notify(`ダウンロードに失敗しました。${(err as Error)?.message ?? ''}`, 'error')
    }
  }

  const remove = async () => {
    const ok = window.confirm(`「${note.title}」を削除します。元に戻せません。よろしいですか？`)
    if (!ok) return
    try {
      await deleteNote(note.id)
      onDeleted(note.id)
      notify('削除しました')
    } catch (err) {
      notify(describeStorageError(err), 'error')
    }
  }

  const memoPreview = note.memo.trim().split('\n')[0]

  return (
    <li className={`note ${expanded ? 'note--open' : ''}`}>
      <button
        type="button"
        className="note__summary"
        onClick={onToggle}
        aria-expanded={expanded}
        aria-controls={`note-body-${note.id}`}
      >
        <span className="note__main">
          <span className="note__title">{note.title}</span>
          <span className="note__meta">
            <span>{formatDateTime(note.createdAt)}</span>
            <span className="note__sep" aria-hidden="true">・</span>
            <span>{formatDuration(note.durationMs)}</span>
            <span className="note__sep" aria-hidden="true">・</span>
            <span>{formatBytes(note.size)}</span>
          </span>
          {!expanded && memoPreview && <span className="note__preview">{memoPreview}</span>}
        </span>
        <span className="note__chev" aria-hidden="true">
          {expanded ? '−' : '＋'}
        </span>
      </button>

      {expanded && (
        <div className="note__body" id={`note-body-${note.id}`}>
          <AudioPlayer noteId={note.id} />

          <label className="field">
            <span className="field__label">タイトル</span>
            <input
              ref={titleRef}
              className="input"
              type="text"
              value={title}
              maxLength={120}
              onChange={(e) => setTitle(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && dirty && !saving) void save()
              }}
            />
          </label>

          <label className="field">
            <span className="field__label">メモ</span>
            <textarea
              className="input input--textarea"
              value={memo}
              rows={4}
              placeholder="話した内容や、あとで見返したいことを書いておけます"
              onChange={(e) => setMemo(e.target.value)}
            />
          </label>

          {saveError && (
            <p className="alert" role="alert">
              {saveError}
            </p>
          )}

          <div className="note__actions">
            <button type="button" className="btn btn--md btn--ink" onClick={() => void save()} disabled={!dirty || saving}>
              {saving ? '保存中…' : 'ノートを保存'}
            </button>
            <span className="note__saved" role="status" aria-live="polite">
              {saving
                ? ''
                : dirty
                  ? '未保存の変更があります'
                  : savedAt
                    ? `✓ 保存しました（${formatDateTime(savedAt).split(' ')[1]}）`
                    : '✓ 保存済み'}
            </span>
          </div>

          <div className="note__tools">
            <button type="button" className="btn btn--sm btn--cream" onClick={() => void download()}>
              音声をダウンロード
            </button>
            <button type="button" className="btn btn--sm btn--cream btn--danger" onClick={() => void remove()}>
              削除
            </button>
            <span className="note__format muted">形式: {extensionFor(note.mimeType)}</span>
          </div>
        </div>
      )}
    </li>
  )
}
