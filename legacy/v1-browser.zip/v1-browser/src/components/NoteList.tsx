import { useMemo } from 'react'
import type { Note } from '../types'
import NoteItem from './NoteItem'

interface Props {
  notes: Note[]
  query: string
  onQueryChange: (q: string) => void
  expandedId: string | null
  justSavedId: string | null
  onToggle: (id: string) => void
  onUpdated: (note: Note) => void
  onDeleted: (id: string) => void
  notify: (text: string, kind?: 'ok' | 'error') => void
  loading: boolean
  loadError: string | null
}

function normalize(s: string): string {
  return s.normalize('NFKC').toLowerCase()
}

export default function NoteList({
  notes,
  query,
  onQueryChange,
  expandedId,
  justSavedId,
  onToggle,
  onUpdated,
  onDeleted,
  notify,
  loading,
  loadError,
}: Props) {
  const filtered = useMemo(() => {
    const q = normalize(query.trim())
    if (!q) return notes
    const words = q.split(/\s+/)
    return notes.filter((n) => {
      const hay = normalize(`${n.title}\n${n.memo}`)
      return words.every((w) => hay.includes(w))
    })
  }, [notes, query])

  return (
    <section className="card list" aria-labelledby="list-heading">
      <div className="list__head">
        <h2 id="list-heading" className="card__title">
          保存した録音 <span className="list__count">{notes.length}件</span>
        </h2>
        <label className="search">
          <span className="visually-hidden">タイトルやメモで検索</span>
          <input
            className="input input--search"
            type="search"
            placeholder="タイトルやメモで検索"
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
          />
        </label>
      </div>

      {loadError && (
        <p className="alert" role="alert">
          {loadError}
        </p>
      )}

      {loading && !loadError && <p className="muted">読み込んでいます…</p>}

      {!loading && !loadError && notes.length === 0 && (
        <div className="empty">
          <p className="empty__title">まだ録音がありません</p>
          <p className="muted">上の「録音をはじめる」から、最初の1件を録ってみましょう。</p>
        </div>
      )}

      {!loading && notes.length > 0 && filtered.length === 0 && (
        <div className="empty">
          <p className="empty__title">「{query}」に合う録音は見つかりませんでした</p>
        </div>
      )}

      {filtered.length > 0 && (
        <ul className="notes">
          {filtered.map((n) => (
            <NoteItem
              key={n.id}
              note={n}
              expanded={expandedId === n.id}
              autoFocusTitle={justSavedId === n.id}
              onToggle={() => onToggle(n.id)}
              onUpdated={onUpdated}
              onDeleted={onDeleted}
              notify={notify}
            />
          ))}
        </ul>
      )}
    </section>
  )
}
