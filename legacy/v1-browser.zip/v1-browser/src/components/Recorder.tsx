import { useEffect, useState } from 'react'
import { checkRecorderSupport, useRecorder, type RecordingResult } from '../useRecorder'
import { formatDuration } from '../format'

interface Props {
  onFinished: (result: RecordingResult) => void
  saving: boolean
}

const STATUS_LABEL = {
  idle: '待機中',
  requesting: 'マイクを準備中…',
  recording: '録音中',
  paused: '一時停止中',
  stopping: '停止しています…',
} as const

export default function Recorder({ onFinished, saving }: Props) {
  const { status, elapsedMs, level, error, start, pause, resume, stop, clearError } = useRecorder({ onFinished })
  const [support] = useState(() => checkRecorderSupport())

  // 録音中はタブのタイトルでも状態が分かるようにする
  useEffect(() => {
    const base = 'やさしい録音ノート'
    if (status === 'recording') document.title = `● 録音中 ${formatDuration(elapsedMs)} | ${base}`
    else if (status === 'paused') document.title = `‖ 一時停止 | ${base}`
    else document.title = base
    return () => {
      document.title = base
    }
  }, [status, elapsedMs])

  const busy = status === 'requesting' || status === 'stopping' || saving
  const active = status === 'recording' || status === 'paused'

  return (
    <section className={`card recorder recorder--${status}`} aria-labelledby="recorder-heading">
      <div className="recorder__head">
        <h2 id="recorder-heading" className="card__title">録音する</h2>
        <span className={`status status--${status}`} role="status" aria-live="polite">
          {status === 'recording' && <span className="status__dot" aria-hidden="true" />}
          {saving ? '保存中…' : STATUS_LABEL[status]}
        </span>
      </div>

      <div className="timer" aria-label="録音時間">
        <span className="timer__digits">{formatDuration(elapsedMs)}</span>
      </div>

      <div className="meter" aria-hidden="true">
        <div className="meter__bar" style={{ transform: `scaleX(${status === 'recording' ? Math.max(0.02, level) : 0})` }} />
      </div>

      {!support.ok && (
        <p className="alert" role="alert">
          {support.reason}
        </p>
      )}

      {error && (
        <div className="alert" role="alert">
          <p>{error}</p>
          <button type="button" className="btn btn--sm btn--cream" onClick={clearError}>
            閉じる
          </button>
        </div>
      )}

      <div className="recorder__actions">
        {!active && (
          <button
            type="button"
            className="btn btn--lg btn--ink"
            onClick={() => void start()}
            disabled={!support.ok || busy}
          >
            <span className="btn__icon btn__icon--rec" aria-hidden="true" />
            {status === 'requesting' ? 'マイクを準備中…' : '録音をはじめる'}
          </button>
        )}
        {status === 'recording' && (
          <button type="button" className="btn btn--lg btn--cream" onClick={pause}>
            <span className="btn__icon btn__icon--pause" aria-hidden="true" />
            一時停止
          </button>
        )}
        {status === 'paused' && (
          <button type="button" className="btn btn--lg btn--yellow" onClick={resume}>
            <span className="btn__icon btn__icon--play" aria-hidden="true" />
            再開する
          </button>
        )}
        {active && (
          <button type="button" className="btn btn--lg btn--ink" onClick={stop} disabled={busy}>
            <span className="btn__icon btn__icon--stop" aria-hidden="true" />
            停止して保存
          </button>
        )}
      </div>

      <p className="recorder__hint">
        {active
          ? '停止すると、すぐにこのブラウザーへ保存されます。あとからタイトルとメモを付けられます。'
          : 'ボタンを押すとマイクの許可を求められます。「許可」を選ぶと録音がはじまります。'}
      </p>
    </section>
  )
}
