import { useEffect, useRef, useState } from 'react'
import { exportBackup, importBackup, type ExportProgress } from '../backup'
import { getStorageEstimate, requestPersistentStorage } from '../db'
import { formatBytes } from '../format'

interface Props {
  noteCount: number
  onImported: () => Promise<void> | void
  notify: (text: string, kind?: 'ok' | 'error') => void
}

export default function BackupPanel({ noteCount, onImported, notify }: Props) {
  const [busy, setBusy] = useState<'export' | 'import' | null>(null)
  const [progress, setProgress] = useState<ExportProgress | null>(null)
  const [estimate, setEstimate] = useState<{ usage: number; quota: number } | null>(null)
  const [persisted, setPersisted] = useState<boolean | null>(null)
  const fileRef = useRef<HTMLInputElement | null>(null)

  useEffect(() => {
    let cancelled = false
    void getStorageEstimate().then((e) => {
      if (!cancelled) setEstimate(e)
    })
    void requestPersistentStorage().then((p) => {
      if (!cancelled) setPersisted(p)
    })
    return () => {
      cancelled = true
    }
  }, [noteCount])

  const doExport = async () => {
    setBusy('export')
    setProgress(null)
    try {
      const n = await exportBackup(setProgress)
      notify(n > 0 ? `${n}件の録音をバックアップファイルに書き出しました` : '書き出せる録音がありませんでした', n > 0 ? 'ok' : 'error')
    } catch (err) {
      notify(`バックアップに失敗しました。${(err as Error)?.message ?? ''}`, 'error')
    } finally {
      setBusy(null)
      setProgress(null)
    }
  }

  const doImport = async (file: File) => {
    setBusy('import')
    setProgress(null)
    try {
      const r = await importBackup(file, setProgress)
      await onImported()
      notify(`復元しました：${r.added}件を追加${r.skipped > 0 ? `、${r.skipped}件は既にあるため省略` : ''}`)
    } catch (err) {
      notify((err as Error)?.message ?? '復元に失敗しました。', 'error')
    } finally {
      setBusy(null)
      setProgress(null)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  return (
    <section className="card backup" aria-labelledby="backup-heading">
      <h2 id="backup-heading" className="card__title">バックアップ</h2>
      <p className="backup__lead">
        録音は<strong>このブラウザーの中だけ</strong>に保存されています。ブラウザーのデータを消したり、端末を替えたりすると失われることがあります。ときどきバックアップを書き出して、ファイルとして残しておいてください。
      </p>

      <div className="backup__actions">
        <button type="button" className="btn btn--md btn--yellow" onClick={() => void doExport()} disabled={busy !== null || noteCount === 0}>
          {busy === 'export' ? '書き出し中…' : 'バックアップを書き出す'}
        </button>
        <button type="button" className="btn btn--md btn--cream" onClick={() => fileRef.current?.click()} disabled={busy !== null}>
          {busy === 'import' ? '復元中…' : 'バックアップから復元'}
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="application/json,.json"
          className="visually-hidden"
          onChange={(e) => {
            const f = e.target.files?.[0]
            if (f) void doImport(f)
          }}
        />
      </div>

      {progress && (
        <p className="muted" role="status" aria-live="polite">
          {progress.done} / {progress.total} 件を処理中…
        </p>
      )}

      <dl className="backup__info">
        {estimate && (
          <div>
            <dt>使用中の容量</dt>
            <dd>
              {formatBytes(estimate.usage)}
              {estimate.quota > 0 && <span className="muted">（上限の目安 {formatBytes(estimate.quota)}）</span>}
            </dd>
          </div>
        )}
        {persisted !== null && (
          <div>
            <dt>保存領域の保護</dt>
            <dd>{persisted ? '有効（ブラウザーが自動で消しにくくなっています）' : '未設定（容量不足時に消される可能性があります）'}</dd>
          </div>
        )}
      </dl>
      <p className="muted backup__note">
        バックアップは 1 つの JSON ファイルで、音声とタイトル・メモをすべて含みます。復元すると、まだ無い録音だけが追加されます。
      </p>
    </section>
  )
}
