import { useCallback, useEffect, useRef, useState } from 'react'

export type RecorderStatus = 'idle' | 'requesting' | 'recording' | 'paused' | 'stopping'

export interface RecordingResult {
  blob: Blob
  mimeType: string
  durationMs: number
  startedAt: number
}

/** ブラウザーが録音できる形式を、優先順に探す */
const MIME_CANDIDATES = [
  'audio/webm;codecs=opus',
  'audio/webm',
  'audio/mp4;codecs=mp4a.40.2',
  'audio/mp4',
  'audio/ogg;codecs=opus',
  'audio/ogg',
]

export function getSupportedMimeType(): string | null {
  if (typeof MediaRecorder === 'undefined') return null
  if (typeof MediaRecorder.isTypeSupported !== 'function') return ''
  for (const type of MIME_CANDIDATES) {
    try {
      if (MediaRecorder.isTypeSupported(type)) return type
    } catch {
      /* 一部ブラウザーは例外を投げる */
    }
  }
  return null
}

export interface RecorderSupport {
  ok: boolean
  reason: string | null
}

export function checkRecorderSupport(): RecorderSupport {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
    if (typeof window !== 'undefined' && !window.isSecureContext) {
      return { ok: false, reason: 'マイクは https または localhost でのみ使えます。アドレスを確認してください。' }
    }
    return { ok: false, reason: 'このブラウザーはマイク録音に対応していません。最新の Chrome / Safari / Edge / Firefox をお使いください。' }
  }
  if (typeof MediaRecorder === 'undefined') {
    return { ok: false, reason: 'このブラウザーは録音機能（MediaRecorder）に対応していません。' }
  }
  if (getSupportedMimeType() === null) {
    return { ok: false, reason: 'このブラウザーが対応している録音形式が見つかりませんでした（webm / mp4 / ogg のいずれも使えません）。' }
  }
  return { ok: true, reason: null }
}

/** getUserMedia の例外を日本語にする */
export function describeMicError(err: unknown): string {
  const e = err as { name?: string; message?: string } | null
  const name = e?.name ?? ''
  switch (name) {
    case 'NotAllowedError':
    case 'PermissionDeniedError':
    case 'SecurityError':
      return 'マイクの使用が許可されていません。アドレスバーの鍵マーク（またはブラウザーの設定）からマイクを「許可」にして、もう一度お試しください。'
    case 'NotFoundError':
    case 'DevicesNotFoundError':
      return 'マイクが見つかりません。マイクが接続されているか確認してください。'
    case 'NotReadableError':
    case 'TrackStartError':
      return 'マイクを使えませんでした。ほかのアプリがマイクを使っている場合は終了してから、もう一度お試しください。'
    case 'OverconstrainedError':
      return 'この条件で使えるマイクがありません。'
    case 'AbortError':
      return 'マイクの起動が中断されました。もう一度お試しください。'
    default:
      return e?.message ? `マイクを使えませんでした（${e.message}）` : 'マイクを使えませんでした。'
  }
}

interface Options {
  /** 録音が終わったとき（手動停止・マイク切断の両方）に呼ばれる */
  onFinished: (result: RecordingResult) => void
}

export function useRecorder({ onFinished }: Options) {
  const [status, setStatus] = useState<RecorderStatus>('idle')
  const [elapsedMs, setElapsedMs] = useState(0)
  const [level, setLevel] = useState(0)
  const [error, setError] = useState<string | null>(null)

  const onFinishedRef = useRef(onFinished)
  useEffect(() => {
    onFinishedRef.current = onFinished
  }, [onFinished])

  const recorderRef = useRef<MediaRecorder | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const mimeRef = useRef('')
  const startedAtRef = useRef(0)
  const accumulatedRef = useRef(0) // 一時停止までに録れた合計ミリ秒
  const segmentStartRef = useRef<number | null>(null) // 現在のセグメント開始時刻
  const audioCtxRef = useRef<AudioContext | null>(null)
  const rafRef = useRef<number | null>(null)
  const statusRef = useRef<RecorderStatus>('idle')

  const updateStatus = useCallback((s: RecorderStatus) => {
    statusRef.current = s
    setStatus(s)
  }, [])

  const currentElapsed = useCallback(() => {
    const seg = segmentStartRef.current
    return accumulatedRef.current + (seg === null ? 0 : performance.now() - seg)
  }, [])

  // 経過時間の更新
  useEffect(() => {
    if (status !== 'recording') return
    const id = window.setInterval(() => setElapsedMs(currentElapsed()), 200)
    return () => window.clearInterval(id)
  }, [status, currentElapsed])

  const stopMeter = useCallback(() => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current)
      rafRef.current = null
    }
    setLevel(0)
  }, [])

  const startMeter = useCallback((stream: MediaStream) => {
    try {
      const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
      if (!Ctx) return
      const ctx = audioCtxRef.current ?? new Ctx()
      audioCtxRef.current = ctx
      if (ctx.state === 'suspended') void ctx.resume()
      const source = ctx.createMediaStreamSource(stream)
      const analyser = ctx.createAnalyser()
      analyser.fftSize = 1024
      source.connect(analyser)
      const buf = new Uint8Array(analyser.fftSize)
      const tick = () => {
        analyser.getByteTimeDomainData(buf)
        let sum = 0
        for (let i = 0; i < buf.length; i++) {
          const v = (buf[i] - 128) / 128
          sum += v * v
        }
        const rms = Math.sqrt(sum / buf.length)
        setLevel(Math.min(1, rms * 3))
        rafRef.current = requestAnimationFrame(tick)
      }
      rafRef.current = requestAnimationFrame(tick)
    } catch {
      /* メーターは補助機能なので失敗しても録音は続ける */
    }
  }, [])

  const releaseStream = useCallback(() => {
    stopMeter()
    streamRef.current?.getTracks().forEach((t) => t.stop())
    streamRef.current = null
    if (audioCtxRef.current) {
      void audioCtxRef.current.close().catch(() => {})
      audioCtxRef.current = null
    }
  }, [stopMeter])

  const start = useCallback(async () => {
    if (statusRef.current !== 'idle') return
    setError(null)
    const support = checkRecorderSupport()
    if (!support.ok) {
      setError(support.reason)
      return
    }
    updateStatus('requesting')
    let stream: MediaStream
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    } catch (err) {
      setError(describeMicError(err))
      updateStatus('idle')
      return
    }
    streamRef.current = stream

    const mimeType = getSupportedMimeType() ?? ''
    let recorder: MediaRecorder
    try {
      recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream)
    } catch (err) {
      releaseStream()
      setError(`録音を開始できませんでした。この形式（${mimeType || '既定'}）に対応していない可能性があります。${(err as Error)?.message ?? ''}`)
      updateStatus('idle')
      return
    }

    chunksRef.current = []
    mimeRef.current = recorder.mimeType || mimeType || 'audio/webm'
    accumulatedRef.current = 0
    segmentStartRef.current = null
    startedAtRef.current = Date.now()
    setElapsedMs(0)

    recorder.ondataavailable = (ev: BlobEvent) => {
      if (ev.data && ev.data.size > 0) chunksRef.current.push(ev.data)
    }
    recorder.onerror = (ev) => {
      const e = (ev as unknown as { error?: Error }).error
      setError(`録音中にエラーが起きました。${e?.message ?? ''}`)
    }
    recorder.onstop = () => {
      if (segmentStartRef.current !== null) {
        accumulatedRef.current += performance.now() - segmentStartRef.current
        segmentStartRef.current = null
      }
      const durationMs = Math.round(accumulatedRef.current)
      setElapsedMs(durationMs)
      const blob = new Blob(chunksRef.current, { type: mimeRef.current })
      chunksRef.current = []
      releaseStream()
      recorderRef.current = null
      updateStatus('idle')
      if (blob.size === 0) {
        setError('音声が録れていませんでした。マイクの入力を確認して、もう一度お試しください。')
        return
      }
      onFinishedRef.current({ blob, mimeType: mimeRef.current, durationMs, startedAt: startedAtRef.current })
    }

    // マイクが抜かれた・OSに奪われた場合は、そこまでの録音を保存する
    stream.getAudioTracks().forEach((track) => {
      track.addEventListener('ended', () => {
        if (recorderRef.current && recorderRef.current.state !== 'inactive') {
          setError('マイクとの接続が切れたため、ここまでの録音を保存しました。')
          try {
            recorderRef.current.stop()
          } catch {
            /* ignore */
          }
        }
      })
    })

    recorderRef.current = recorder
    try {
      recorder.start(1000) // 1秒ごとにデータを受け取り、途中で落ちても失いにくくする
    } catch (err) {
      releaseStream()
      recorderRef.current = null
      setError(`録音を開始できませんでした。${(err as Error)?.message ?? ''}`)
      updateStatus('idle')
      return
    }
    segmentStartRef.current = performance.now()
    startMeter(stream)
    updateStatus('recording')
  }, [releaseStream, startMeter, updateStatus])

  const pause = useCallback(() => {
    const r = recorderRef.current
    if (!r || r.state !== 'recording') return
    try {
      r.pause()
    } catch {
      return
    }
    if (segmentStartRef.current !== null) {
      accumulatedRef.current += performance.now() - segmentStartRef.current
      segmentStartRef.current = null
    }
    setElapsedMs(accumulatedRef.current)
    stopMeter()
    updateStatus('paused')
  }, [stopMeter, updateStatus])

  const resume = useCallback(() => {
    const r = recorderRef.current
    if (!r || r.state !== 'paused') return
    try {
      r.resume()
    } catch {
      return
    }
    segmentStartRef.current = performance.now()
    if (streamRef.current) startMeter(streamRef.current)
    updateStatus('recording')
  }, [startMeter, updateStatus])

  const stop = useCallback(() => {
    const r = recorderRef.current
    if (!r || r.state === 'inactive') return
    updateStatus('stopping')
    try {
      r.stop()
    } catch (err) {
      setError(`停止に失敗しました。${(err as Error)?.message ?? ''}`)
      updateStatus('idle')
    }
  }, [updateStatus])

  // ページを閉じるときの後始末と、録音中の離脱警告
  useEffect(() => {
    const onBeforeUnload = (ev: BeforeUnloadEvent) => {
      if (statusRef.current === 'recording' || statusRef.current === 'paused') {
        ev.preventDefault()
      }
    }
    window.addEventListener('beforeunload', onBeforeUnload)
    return () => {
      window.removeEventListener('beforeunload', onBeforeUnload)
      releaseStream()
    }
  }, [releaseStream])

  const clearError = useCallback(() => setError(null), [])

  return { status, elapsedMs, level, error, start, pause, resume, stop, clearError }
}
