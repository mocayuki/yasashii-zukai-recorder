import { useCallback, useEffect, useRef, useState } from 'react'
import type { Note } from './types'
import { describeStorageError, getAllNotes, isIndexedDBAvailable, saveNote } from './db'
import { defaultTitle, downloadBlob, extensionFor, newId, safeFileName } from './format'
import type { RecordingResult } from './useRecorder'
import Recorder from './components/Recorder'
import NoteList from './components/NoteList'
import BackupPanel from './components/BackupPanel'
import Toast, { type ToastMessage } from './components/Toast'

interface PendingRecording extends RecordingResult {
  error: string
}

export default function App() {
  const [notes, setNotes] = useState<Note[]>([])
  const dbAvailable = isIndexedDBAvailable()
  const [loading, setLoading] = useState(dbAvailable)
  const [loadError, setLoadError] = useState<string | null>(
    dbAvailable ? null : 'このブラウザーでは保存機能（IndexedDB）が使えません。プライベートモードを解除するか、別のブラウザーをお試しください。',
  )
  const [query, setQuery] = useState('')
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [justSavedId, setJustSavedId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [pending, setPending] = useState<PendingRecording | null>(null)
  const [toast, setToast] = useState<ToastMessage | null>(null)
  const toastTimer = useRef<number | null>(null)
  const listRef = useRef<HTMLDivElement | null>(null)

  const notify = useCallback((text: string, kind: 'ok' | 'error' = 'ok') => {
    if (toastTimer.current) window.clearTimeout(toastTimer.current)
    setToast({ id: Date.now(), text, kind })
    toastTimer.current = window.setTimeout(() => setToast(null), kind === 'error' ? 7000 : 3500)
  }, [])

  const reload = useCallback(async () => {
    try {
      const all = await getAllNotes()
      setNotes(all)
      setLoadError(null)
    } catch (err) {
      setLoadError(describeStorageError(err))
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (dbAvailable) void reload()
  }, [dbAvailable, reload])

  const persistRecording = useCallback(
    async (result: RecordingResult) => {
      setSaving(true)
      const now = Date.now()
      const note: Note = {
        id: newId(),
        title: defaultTitle(result.startedAt),
        memo: '',
        createdAt: result.startedAt,
        updatedAt: now,
        durationMs: result.durationMs,
        mimeType: result.mimeType,
        size: result.blob.size,
      }
      try {
        await saveNote(note, result.blob)
        setPending(null)
        setNotes((prev) => [note, ...prev.filter((n) => n.id !== note.id)])
        setQuery('')
        setExpandedId(note.id)
        setJustSavedId(note.id)
        notify('録音を保存しました。タイトルとメモを付けられます')
        window.setTimeout(() => listRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100)
      } catch (err) {
        const msg = describeStorageError(err)
        setPending({ ...result, error: msg })
        notify(`録音は保存できませんでした。${msg}`, 'error')
      } finally {
        setSaving(false)
      }
    },
    [notify],
  )

  const downloadPending = () => {
    if (!pending) return
    const name = `${safeFileName(defaultTitle(pending.startedAt))}.${extensionFor(pending.mimeType)}`
    downloadBlob(pending.blob, name)
    notify('音声のダウンロードをはじめました。ファイルとして残しておけます')
  }

  return (
    <div className="app">
      <header className="site-header">
        <div className="head">
          <a className="head__logo" href="#top">
            <span className="head__mark" aria-hidden="true" />
            やさしい録音ノート
          </a>
          <span className="pill">自分専用</span>
        </div>
      </header>

      <main id="top" className="main">
        <div className="intro">
          <h1 className="intro__title">
            <span>話して、</span>
            <span>残して、</span>
            <span>あとで読む。</span>
          </h1>
          <p className="intro__lead">
            <span>マイクで録音して、</span>
            <span>タイトルとメモを付けて保存する、</span>
            <span>自分だけの録音ノートです。</span>
          </p>
        </div>

        <div className="layout">
          <div className="layout__side">
            <Recorder onFinished={(r) => void persistRecording(r)} saving={saving} />

            {pending && (
              <section className="card card--alert" aria-labelledby="pending-heading">
                <h2 id="pending-heading" className="card__title">保存できなかった録音があります</h2>
                <p>{pending.error}</p>
                <p className="muted">この録音はまだ画面の中にだけ残っています。ページを閉じる前に、どちらかを選んでください。</p>
                <div className="card__actions">
                  <button type="button" className="btn btn--md btn--ink" onClick={() => void persistRecording(pending)} disabled={saving}>
                    もう一度保存する
                  </button>
                  <button type="button" className="btn btn--md btn--yellow" onClick={downloadPending}>
                    音声をダウンロードして残す
                  </button>
                </div>
              </section>
            )}

            <BackupPanel noteCount={notes.length} onImported={reload} notify={notify} />
          </div>

          <div className="layout__list" ref={listRef}>
            <NoteList
              notes={notes}
              query={query}
              onQueryChange={setQuery}
              expandedId={expandedId}
              justSavedId={justSavedId}
              onToggle={(id) => {
                setExpandedId((cur) => (cur === id ? null : id))
                if (justSavedId !== id) setJustSavedId(null)
              }}
              onUpdated={(note) => setNotes((prev) => prev.map((n) => (n.id === note.id ? note : n)))}
              onDeleted={(id) => {
                setNotes((prev) => prev.filter((n) => n.id !== id))
                setExpandedId((cur) => (cur === id ? null : cur))
              }}
              notify={notify}
              loading={loading}
              loadError={loadError}
            />
          </div>
        </div>
      </main>

      <footer className="site-footer">
        <p>録音はインターネットに送られず、このブラウザーの中だけに保存されます。</p>
        <p className="muted">文字起こし・AI要約は、外部サービスと費用を選んでから追加する予定です。</p>
      </footer>

      <Toast toast={toast} onClose={() => setToast(null)} />
    </div>
  )
}
