# やさしい録音ノート（yasashii-voice-notes）

自分のマイク音声を録音して、タイトルとメモを付けて保存する、自分専用のブラウザーアプリです。
React + TypeScript + Vite で作られていて、録音は MediaRecorder、保存はブラウザーの IndexedDB を使います。
音声はインターネットに送られません。

## できること（初期版）

- マイク録音の開始・一時停止・再開・停止
- 録音時間と状態（待機中 / 録音中 / 一時停止中）の表示、入力レベルの目安
- 停止と同時にブラウザーへ保存。保存できたことをトースト表示で確認できる
- 保存した録音の再生、タイトルとメモの編集
- 一覧表示と、タイトル・メモによる検索
- 音声ファイルのダウンロード
- 全録音とノートを 1 つの JSON ファイルに書き出すバックアップと、その復元
- マイク権限の拒否、保存失敗、対応していない録音形式などを日本語で案内

## 使い方

```bash
npm install
npm run dev
```

表示された `http://localhost:5173` をブラウザーで開きます。
マイクは `https` か `localhost` でしか使えません。スマートフォンから試すときは、`npm run dev -- --host` で LAN に公開したうえで https 化するか、Vercel / Cloudflare Pages などに配置してください。

本番用のビルドは次のとおりです。`dist/` の中身を静的ホスティングに置けば動きます。

```bash
npm run build
```

## 保存場所とバックアップ

録音はこのブラウザーの IndexedDB にだけ保存されます。ブラウザーのサイトデータを削除したり、端末やブラウザーを替えたりすると失われます。
画面の「バックアップを書き出す」で JSON ファイルを保存し、「バックアップから復元」で戻せます。復元は、まだ無い録音だけを追加します。

## 録音形式について

ブラウザーが対応している形式を自動で選びます。

| ブラウザー | 形式 | 拡張子 |
| --- | --- | --- |
| Chrome / Edge / Firefox | audio/webm (Opus) | .webm |
| Safari (Mac / iPhone) | audio/mp4 (AAC) | .m4a |

別のブラウザーで復元した録音も、そのブラウザーが再生に対応していれば聞けます。

## 今後の予定

- 文字起こし
- AI 要約

どちらも外部サービスと費用を選んでから実装します。

## ディレクトリ

```
src/
  App.tsx                 画面全体・保存の流れ
  useRecorder.ts          MediaRecorder を扱うフック
  db.ts                   IndexedDB の読み書き
  backup.ts               バックアップの書き出し・復元
  format.ts               時間・日付・ファイル名の整形
  components/Recorder.tsx     録音カード
  components/NoteList.tsx     一覧と検索
  components/NoteItem.tsx     1 件の再生・編集・ダウンロード・削除
  components/AudioPlayer.tsx  IndexedDB から読み出して再生
  components/BackupPanel.tsx  バックアップ・復元
  components/Toast.tsx        画面下の通知
  styles.css              デザイン（Zen Maru Gothic、黄色 #FFD95C、墨 #1C1812）
```
